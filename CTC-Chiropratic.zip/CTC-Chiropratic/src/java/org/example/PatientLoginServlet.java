package org.example;
/*
    Last Modified: 3/17/2025
    Author: Victorino Martinez
*/
import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

import org.example.Patients;

@WebServlet(name = "PatientLoginServlet", urlPatterns = {"/PatientLoginServlet"})
public class PatientLoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String id = "";
        String pw = "";

        try {
            id = request.getParameter("CID");
            pw = request.getParameter("PASS");
            System.out.println("---Password Received---");

            //Patients Business Object
            Patients p1;
            p1 = new Patients();

            //getting Customer info from CustomerBO
            p1.selectDB(id);
            String CID = p1.getpatid();
            String PASS = p1.getpwd();
            System.out.println("Customer ID: " + p1.getpatid());
            System.out.println("Password: " + p1.getpwd());

            //Putting Customer object into the Session
            HttpSession ses1;
            ses1 = request.getSession();
            ses1.setAttribute("p1", p1);
            System.out.println("Customer added to Session/scheduling Patient-Home.jsp");


            //forward page to AccountLookup.jsp if login matches database/ else forward to ErrorPage.jsp
            if (pw.equals(PASS) && id.equals(CID)) {
                RequestDispatcher rd = request.getRequestDispatcher("/Patient-Home.jsp");
                rd.forward(request, response);

            } else {
                RequestDispatcher rd = request.getRequestDispatcher("/Error.jsp");
                rd.forward(request, response);
            }


        } finally {
            out.close();

        }//end try/finally

    }//end processRequest()

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);

    }

}//end LoginServlet()